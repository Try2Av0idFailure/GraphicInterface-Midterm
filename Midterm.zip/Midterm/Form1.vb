﻿Public Class frmBuilding
    Dim dblInput As Double
    Private Sub BtnConvert_Click(sender As Object, e As EventArgs) Handles btnConvert.Click
        Try
            dblInput = Convert.ToDouble(txtInput.Text)
            If dblInput > 0 Then

                If radbtnInch.Checked = True Then
                    lblResult.Text = Convert.ToString(dblInput * 0.0254)
                Else
                    lblResult.Text = Convert.ToString(dblInput / 0.0254)
                End If
            Else
                MsgBox("Please enter a valid input, no negatives allowed in this neighborhood")
                txtInput.Clear()
                txtInput.Focus()
                lblResult.Text = ""
            End If


        Catch ex As Exception
            MsgBox("Please enter a valid input, use numbers or leave")
            txtInput.Clear()
            txtInput.Focus()
            lblResult.Text = ""
        End Try



    End Sub


    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click, MyBase.Load
        txtInput.Clear()
        txtInput.Focus()
        lblResult.Text = ""
        radbtnInch.Checked = True
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class

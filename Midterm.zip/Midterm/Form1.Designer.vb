﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBuilding
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnConvert = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblConverter = New System.Windows.Forms.Label()
        Me.lblEnterVal = New System.Windows.Forms.Label()
        Me.radbtnInch = New System.Windows.Forms.RadioButton()
        Me.radbtnMeter = New System.Windows.Forms.RadioButton()
        Me.txtInput = New System.Windows.Forms.TextBox()
        Me.grpboxRadBtn = New System.Windows.Forms.GroupBox()
        Me.lblResult = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpboxRadBtn.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox1.Image = Global.Midterm.My.Resources.Resources.building__1_
        Me.PictureBox1.Location = New System.Drawing.Point(0, 25)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(293, 156)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'btnConvert
        '
        Me.btnConvert.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnConvert.Location = New System.Drawing.Point(163, 347)
        Me.btnConvert.Name = "btnConvert"
        Me.btnConvert.Size = New System.Drawing.Size(75, 23)
        Me.btnConvert.TabIndex = 1
        Me.btnConvert.Text = "Convert"
        Me.btnConvert.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClear.Location = New System.Drawing.Point(390, 347)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 2
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnExit.Location = New System.Drawing.Point(605, 347)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblConverter
        '
        Me.lblConverter.AutoSize = True
        Me.lblConverter.Location = New System.Drawing.Point(387, 25)
        Me.lblConverter.Name = "lblConverter"
        Me.lblConverter.Size = New System.Drawing.Size(53, 13)
        Me.lblConverter.TabIndex = 4
        Me.lblConverter.Text = "Converter"
        '
        'lblEnterVal
        '
        Me.lblEnterVal.Location = New System.Drawing.Point(390, 74)
        Me.lblEnterVal.Name = "lblEnterVal"
        Me.lblEnterVal.Size = New System.Drawing.Size(96, 56)
        Me.lblEnterVal.TabIndex = 5
        Me.lblEnterVal.Text = "Enter value and choose a conversion"
        '
        'radbtnInch
        '
        Me.radbtnInch.AutoSize = True
        Me.radbtnInch.ForeColor = System.Drawing.SystemColors.Control
        Me.radbtnInch.Location = New System.Drawing.Point(36, 19)
        Me.radbtnInch.Name = "radbtnInch"
        Me.radbtnInch.Size = New System.Drawing.Size(104, 17)
        Me.radbtnInch.TabIndex = 6
        Me.radbtnInch.TabStop = True
        Me.radbtnInch.Text = "Inches to Meters"
        Me.radbtnInch.UseVisualStyleBackColor = True
        '
        'radbtnMeter
        '
        Me.radbtnMeter.AutoSize = True
        Me.radbtnMeter.ForeColor = System.Drawing.SystemColors.Control
        Me.radbtnMeter.Location = New System.Drawing.Point(36, 42)
        Me.radbtnMeter.Name = "radbtnMeter"
        Me.radbtnMeter.Size = New System.Drawing.Size(104, 17)
        Me.radbtnMeter.TabIndex = 7
        Me.radbtnMeter.TabStop = True
        Me.radbtnMeter.Text = "Meters to Inches"
        Me.radbtnMeter.UseVisualStyleBackColor = True
        '
        'txtInput
        '
        Me.txtInput.BackColor = System.Drawing.Color.Indigo
        Me.txtInput.ForeColor = System.Drawing.SystemColors.Window
        Me.txtInput.Location = New System.Drawing.Point(517, 74)
        Me.txtInput.Name = "txtInput"
        Me.txtInput.Size = New System.Drawing.Size(100, 20)
        Me.txtInput.TabIndex = 8
        '
        'grpboxRadBtn
        '
        Me.grpboxRadBtn.BackColor = System.Drawing.Color.Indigo
        Me.grpboxRadBtn.Controls.Add(Me.radbtnInch)
        Me.grpboxRadBtn.Controls.Add(Me.radbtnMeter)
        Me.grpboxRadBtn.ForeColor = System.Drawing.SystemColors.Control
        Me.grpboxRadBtn.Location = New System.Drawing.Point(405, 169)
        Me.grpboxRadBtn.Name = "grpboxRadBtn"
        Me.grpboxRadBtn.Size = New System.Drawing.Size(265, 74)
        Me.grpboxRadBtn.TabIndex = 9
        Me.grpboxRadBtn.TabStop = False
        Me.grpboxRadBtn.Text = "Convert Measurement"
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.Location = New System.Drawing.Point(547, 307)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(13, 13)
        Me.lblResult.TabIndex = 10
        Me.lblResult.Text = "L"
        '
        'frmBuilding
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.grpboxRadBtn)
        Me.Controls.Add(Me.txtInput)
        Me.Controls.Add(Me.lblEnterVal)
        Me.Controls.Add(Me.lblConverter)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnConvert)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmBuilding"
        Me.Text = "Building Plans Conversion"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpboxRadBtn.ResumeLayout(False)
        Me.grpboxRadBtn.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnConvert As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblConverter As Label
    Friend WithEvents lblEnterVal As Label
    Friend WithEvents radbtnInch As RadioButton
    Friend WithEvents radbtnMeter As RadioButton
    Friend WithEvents txtInput As TextBox
    Friend WithEvents grpboxRadBtn As GroupBox
    Friend WithEvents lblResult As Label
End Class
